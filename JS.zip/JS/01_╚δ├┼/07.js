//声明函数
function fun(){
	document.getElementById("info").innerHTML="<img src='../../img/ajax.jpg' />";
}