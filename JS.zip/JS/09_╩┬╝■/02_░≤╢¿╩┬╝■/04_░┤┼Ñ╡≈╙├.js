//为当前页面添加onload事件
window.onload = function f(){
    //找到按钮添加绑定事件
    document.getElementById("btn").onclick = function (){
        alert(1)
    }

}