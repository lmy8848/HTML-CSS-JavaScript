function f(){
    o = document.getElementById("info")
    o.innerHTML = o.innerHTML + "<img src='../../img/on.png'>"
}